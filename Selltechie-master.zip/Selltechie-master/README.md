# Selltechie
It is a website made using django framework.It deals with buying and selling of old-tech gadgets.
Works on pycharm platform.
Payment gateway is also conected with it.
